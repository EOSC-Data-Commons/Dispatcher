# TODO
- my location: https://github.com/SteffenBrinckmann/Dispatcher/tree/modemaLite_1

{
  "task_id": "e74b9b43-deef-423a-9fdb-6a1532d0531d"
}
{
  "task_id": "e74b9b43-deef-423a-9fdb-6a1532d0531d",
  "status": "SUCCESS",
  "result": {
    "url": "https://replay.notebooks.egi.eu/v2/git/https%3A%2F%2Fdev1.player.eosc-data-commons.eu%2Fgit%2F5a8b265e-0377-4c0c-9715-e4a30316cd8a/HEAD"
  }
}


# Notes on this ro-crate
RO-crate example of tensile-testing analysis in materials science [wikipedia](https://en.wikipedia.org/wiki/Tensile_testing). Some features of this example
- the input-files inside the ro-crate
- uses a requirements file to define all libraries, incl. the exact version (to allow to verify reproducibility)
- uses an python source file inside the ro-crate

# When creating an ro-crate

## Setup data
1. go to [github](https://github.com/EOSC-Data-Commons/Dispatcher) and clone repository
2. go to test folder and create a new test
1. go into it and create two folders (input and source),
   - put the research data into input.
   - put a starting source file YYY and a requirements.txt file into source. Make sure the YYY file runs successfully.
2. create ro-crate-metadata.json inside the test folder

## Validate
Validate that the ro-crate is fulfilling the requirements (incl. metadata.json and data-files)
1. install
   ``` bash
   pip install roc-validator
   ```
2. execute
   ``` bash
   rocrate-validator validate modemaLite_tensileTesting/ -p ro-crate -f json
   ```

## Dispatcher
Go to [dispatcher](https://dev1.player.eosc-data-commons.eu/oauth2/login) and see if you can log-in. You can [sign up](https://aai-demo.egi.eu/auth/realms/id/account/#/enroll?groupPath=/vo.eosc-data-commons.eu). Please note that when you get an unauthorized error: it is good to close the browser to start again and see if a restart helps.
1. **Test if dispatcher works**: Go to "GET /oauth2/token Get Token" and click **"Try it out"** and **"Execute"**. You should get a json with a token.
   ``` bash
   curl -X 'GET' 'https://dev1.player.eosc-data-commons.eu/oauth2/token' -H 'accept: application/json'
   ```
2. **Test if services are executed**: Go to "POST /requests/zip_rocrate/ Zip Rocrate" and click **"Try it out"**. Go to the data folder on your computer, zip the two files in test/simple-binder and upload that zip file. Click **"Execute"**

   ``` bash
   curl -X 'POST' 'https://dev1.player.eosc-data-commons.eu/requests/zip_rocrate/' -H 'accept: application/json' -H 'Content-Type: multipart/form-data' -F 'zipfile=@test.zip;type=application/zip'
   ```
   You should get a 200-response body with a task_id. You can test that task_id with the server at the GET /requests/{task_id} Status" endpoint. **"Try it out"**, paste in the task_id and click **"Execute"**
   ``` bash
   curl -X 'GET'  'https://dev1.player.eosc-data-commons.eu/requests/3918dae4-cabb-438c-b86c-23d6c0f8ce25' -H 'accept: application/json'
   ```
   You should get a 200-response body with a json
   ``` json
   {
      "task_id": "3918dae4-cabb-438c-b86c-23d6c0f8ce25",
      "status": "SUCCESS",
      "result": {
         "url": "https://replay.notebooks.egi.eu/v2/git/https%3A%2F%2Fdev1.player.eosc-data-commons.eu%2Fgit%2F457dc9fe-93c8-4af2-8cdd-356f33d650cd/HEAD"
         }
      }
   ```

# Feedback: order of severity
- Assume that the Dispatcher also returns the data: POST data, check success, GET data
  - Other tools could also use the dispatcher, single point of execution
- Log-in process is too complicated:
  - ask all people for their orcid, pre-approve all those orcid, done
- Optional: hierarchical folders would be great (source, input, ...). Avoid issues for automatized ro-crate creation
- Tests are not valid ro-crates, yet.

# FAQ
- **In the ro-crate, the user has to specify a 'destination' which is the service that runs the job. If I have to specify that service, why would I not run it there directly?**
The concept of the dispatcher is to prepare the environment in the destination service, so that users can simply open the url and run the workflow. Dispatcher is not meant as a standalone service, but it will be utilized by the actual web UI and chatbot. The idea is for the researches to talk to a chatbot about the future research and the result should be a dataset and workflow choice, which will be prepared by Dispatcher.